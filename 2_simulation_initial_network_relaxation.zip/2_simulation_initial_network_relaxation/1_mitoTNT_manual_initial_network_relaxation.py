#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
import os
import readdy

###############################################################################
# PARAMETERS
###############################################################################
out_path = "/home/mattliao/agent_based_model/readdy/01new_ice/latest/output_stride/"
    
PARAMS = {
    # Simulation / integrator
    "box_size": [400.0, 400.0, 0.01],
    "repulsion_force_constant": 10.0,
    "bond_length": 4.0, #was 4
    "bond_force_constant": 100.0,
    
    "angle_force_constant": 10.0,
    "diffusion_constant": 0.002,
    "timestep": 0.2,
    "n_steps": 10000,

    # Branching
    "branch_chance": 0.15, #init 0.15 TO 0
    "branch_length": 5,

    # Exclusion around bubble
    "bubble_exclusion_radius": 50.0, #init 30

    # Box potential
    "box_force_constant": 200.0,

    # Output / checkpointing

    "output_file": out_path + "test.h5",
    "checkpoint_dir": out_path + "checkpoints_box_size_0/",
    "checkpoint_stride": 1000,
    "max_n_saves": 10,

    # Observables
    "observe_stride": 100,
    "trajectory_stride": 100,

    # Polylines scaling
    "scale": 0.55 #innit 55
}

###############################################################################
# HELPER FUNCTIONS
###############################################################################

def subdivide_polyline(points, step):
    """
    Returns a subdivided version of the input 'points' (3D) such that consecutive 
    points are ~'step' apart. Edges connect i->i+1.
    """
    subdivided = [points[0]]
    for i in range(len(points) - 1):
        start = points[i]
        end = points[i + 1]
        seg = end - start
        dist = np.linalg.norm(seg)
        if dist < 1e-12:
            continue
        direction = seg / dist
        n_steps = int(dist // step)
        leftover = dist - n_steps * step

        for k in range(n_steps):
            new_pt = start + direction * (step * (k + 1))
            subdivided.append(new_pt)

        # Snap the last subdivided point to the actual end
        if leftover > 0:
            subdivided[-1] = end

    return subdivided


def assign_species_by_degree(num_nodes, edges):
    """
    Assign each node a species based on its degree:
      - 0 or 1 edge -> mito_node_1
      - 2 edges -> mito_node_2
      - >=3 edges -> mito_node_3
    """
    counts = [0] * num_nodes
    for e in edges:
        counts[e[0]] += 1
        counts[e[1]] += 1

    types = []
    for count in counts:
        if count <= 1:
            types.append("mito_node_1")
        elif count == 2:
            types.append("mito_node_2")
        else:
            types.append("mito_node_3")
    return types


def finalize_topology(node_positions, edges, simulation):
    """
    Convert node positions & edges into a ReaDDy topology,
    with adjacency-based species assignment.
    """
    node_positions = np.array(node_positions)
    num_nodes = len(node_positions)

    species = assign_species_by_degree(num_nodes, edges)
    top = simulation.add_topology(
        "mitochondria",
        particle_types=species,
        positions=node_positions
    )
    graph = top.get_graph()
    for e in edges:
        graph.add_edge(e[0], e[1])


def is_near_bubble(pos, bubble_positions, threshold):
    """
    Returns True if 'pos' is within 'threshold' distance of
    any node in 'bubble_positions'.
    """
    for bpos in bubble_positions:
        if np.linalg.norm(pos - bpos) < threshold:
            return True
    return False


def build_polyline_with_branches(pline, simulation, bond_length, 
                                 branch_chance=0.0, branch_length=0, 
                                 exclude_positions=None, exclude_radius=0.0):
    """
    1) Subdivide the polyline.
    2) Optionally add branches from random nodes (unless near 'exclude_positions').
    3) Finalize the topology in the simulation.

    Returns the node_positions that were created.
    """
    node_positions = subdivide_polyline(pline, step=bond_length)
    edges = [(i, i + 1) for i in range(len(node_positions) - 1)]

    # If no branching needed, just finalize and return
    if branch_chance <= 0.0 or branch_length < 1:
        finalize_topology(node_positions, edges, simulation)
        return node_positions

    for i in range(len(node_positions)):
        # If exclude_positions provided, skip branch creation if inside the threshold
        if exclude_positions is not None and \
           is_near_bubble(node_positions[i], exclude_positions, exclude_radius):
            continue

        # Otherwise, attempt to branch
        if np.random.random() < branch_chance:
            # Decide direction based on adjacent segment (or previous if at the end)
            if i < len(node_positions) - 1:
                main_seg = node_positions[i + 1] - node_positions[i]
            else:
                main_seg = node_positions[i] - node_positions[i - 1]

            dx, dy = main_seg[0], main_seg[1]
            # Make a perpendicular vector in the x-y plane
            if np.random.rand() < 0.5:
                perp = np.array([dy, -dx, 0.0])
            else:
                perp = np.array([-dy, dx, 0.0])

            length_perp = np.linalg.norm(perp)
            if length_perp < 1e-5:
                continue
            perp /= length_perp

            prev_idx = i
            for _ in range(branch_length):
                new_pos = node_positions[prev_idx] + perp * bond_length
                node_positions.append(new_pos)
                new_idx = len(node_positions) - 1
                edges.append((prev_idx, new_idx))
                prev_idx = new_idx

    finalize_topology(node_positions, edges, simulation)
    return node_positions


def create_readdy_system(params):
    """
    Create and configure the ReactionDiffusionSystem, including all species, 
    potentials, and topology force fields.
    """
    
    #TODO add reaction here
    system = readdy.ReactionDiffusionSystem(box_size=params["box_size"])
    system.topologies.add_type("mitochondria")
    species_list = ["mito_node_1", "mito_node_2", "mito_node_3"]
    for species in species_list:
      system.add_topology_species(species, params["diffusion_constant"])
    
    '''
     "central_point1", "central_point2","central_point3", "central_point4"]
    for species in species_list:
        if species == "central_point1":
            system.add_species(species, 0.0)  # Zero diffusion
        elif species == "central_point2":
            system.add_species(species, 0.0)
        elif species == "central_point3":
            system.add_species(species, 0.0)
        elif species == "central_point4":
            system.add_species(species, 0.0)
        else:
            system.add_topology_species(species, params["diffusion_constant"])
    '''
    
    # Add topology species (INCLUDING central_points)
    #species_list = ["mito_node_1", "mito_node_2", "mito_node_3"]
    #for species in species_list:
    #        system.add_topology_species(species, params["diffusion_constant"])

    # Box potential (unchanged)
    system_origin = [-params["box_size"][0] / 2,
                     -params["box_size"][1] / 2,
                     -params["box_size"][2] / 2]
    for ptype in ["mito_node_1", "mito_node_2", "mito_node_3"]:
        system.potentials.add_box(
            particle_type=ptype,
            force_constant=params["box_force_constant"],
            origin=system_origin,
            extent=params["box_size"]
        )

    # Pairwise harmonic repulsions
    pairs = [
        ("mito_node_1", "mito_node_1"), ("mito_node_1", "mito_node_2"),
        ("mito_node_1", "mito_node_3"), ("mito_node_2", "mito_node_2"),
        ("mito_node_2", "mito_node_3"), ("mito_node_3", "mito_node_3")
    ]
    for p1, p2 in pairs:
        system.potentials.add_harmonic_repulsion(
            p1, p2,
            force_constant=params["repulsion_force_constant"],
            interaction_distance=params["bond_length"]
        )

    # Harmonic bonds (all combos of mito_node_x, mito_node_y)
    node_types = ["mito_node_1", "mito_node_2", "mito_node_3"]
    for a in node_types:
        for b in node_types:
            system.topologies.configure_harmonic_bond(
                a, b,
                force_constant=params["bond_force_constant"],
                length=params["bond_length"]
            )

    # Harmonic angles
    # Each tuple: (node triplet, equilibrium angle)
    angle_setups = [
        (("mito_node_1", "mito_node_2", "mito_node_2"), np.pi),
        (("mito_node_2", "mito_node_2", "mito_node_2"), np.pi),
        (("mito_node_1", "mito_node_3", "mito_node_2"), np.pi / 3),
        (("mito_node_2", "mito_node_3", "mito_node_2"), np.pi / 3),
        (("mito_node_3", "mito_node_3", "mito_node_3"), np.pi / 3),
    ]
    for triplet, angle in angle_setups:
        system.topologies.configure_harmonic_angle(
            *triplet,
            force_constant=params["angle_force_constant"],
            equilibrium_angle=angle
        )

    return system


def run_simulation(simulation, params):
    """
    Set simulation parameters, enable checkpointing/observables,
    run the actual simulation, and convert to XYZ at the end.
    """
    # Basic setup
    simulation.integrator = "EulerBDIntegrator"
    simulation.reaction_handler = "Gillespie"
    simulation.output_file = params["output_file"]

    # Remove old file if present
    if os.path.exists(simulation.output_file):
        os.remove(simulation.output_file)

    # Observables
    sim_stride = params["observe_stride"]
    simulation.observe.topologies(stride=sim_stride)
    simulation.observe.particles(stride=sim_stride)
    simulation.record_trajectory(stride=params["trajectory_stride"])

    # Checkpoints
    simulation.make_checkpoints(
        stride=params["checkpoint_stride"],
        output_directory=params["checkpoint_dir"],
        max_n_saves=params["max_n_saves"]
    )
    simulation.list_checkpoint_files(params["checkpoint_dir"])

    # Performance
    simulation.kernel_configuration.n_threads = 8
    simulation.progress_output_stride = 10
    simulation.show_progress = True

    # Run
    print("Running simulation...")
    simulation.run(
        n_steps=params["n_steps"],
        timestep=params["timestep"]
    )

    # Post-processing
    trajectory = readdy.Trajectory(params["output_file"])
    trajectory.convert_to_xyz()
    print("Simulation complete!")


def main(params):
    """
    Main entry point: define polylines, scale & center them, 
    create the system and simulation, build topologies, then run.
    """

    # Define polylines
    poly_left = np.array([
        [-90., 280., 0.],
        [-80., 230., 0.],
        [-70., 170., 0.],
        [-48., 140., 0.],
    ])
    poly_right = np.array([
        [20., 240., 0.],
        [25., 200., 0.],
        [30., 180., 0.],
    ])
    poly_bubble = np.array([
        [-50., 170., 0.],
        [-30., 190., 0.],
        [0.,   220., 0.],
        [20.,  200., 0.],
        [30.,  180., 0.],
        [10.,  170., 0.],
        [-50., 170., 0.],
    ])
    poly_bottom = np.array([
        [-5., 163.,  0.],
        [-5.,  83.,  0.],
        [-5.,   33.,  0.],
        [-5., 3.,  0.],
    ])
    
    poly_top = np.array([
      [-40., 230., 0.],
      [-50., 220., 0.],
      [-30., 210., 0.],
      [-10., 220., 0.],
      [10., 230., 0.],
    ])
    
    poly_upper_right = np.array([
      [35., 300., 0.],  # Start further right than "right" polyline
      [75., 290., 0.],
      [115., 270., 0.],
      [145., 240., 0.],
    ])
    
    poly_lower_right = np.array([
      [38., 190., 0.],
      [78., 150., 0.],
      [118., 120., 0.],
      [148., 40., 0.],
    ])
    
    #poly_upper_left_arc = np.array([
    #  [-200., 300., 0.],
    #  [-170., 330., 0.],
    #  [-130., 340., 0.],
    #  [-90., 330., 0.],
    #  [-60., 300., 0.],
    #])
    
    #poly_far_left = np.array([
    #  [-180., 250., 0.],  # Much further left than "poly_left"
    #  [-180., 150., 0.],
    #  [-180., 50., 0.],
    #  [-180., -50., 0.],
    #])

    named_polylines = {
        "bubble": poly_bubble,
        "left":   poly_left,
        "right":  poly_right,
        "bottom": poly_bottom,
        "top": poly_top,
        "upper_right" : poly_upper_right,
        "lower_right" : poly_lower_right
        #"upper_left" : poly_upper_left_arc,
        #"far_left" : poly_far_left
    }

    # Scale and center
    all_points = []
    for k, pline in named_polylines.items():
        named_polylines[k] = pline * params["scale"]
        all_points.append(named_polylines[k])
    all_points = np.concatenate(all_points, axis=0)
    centroid = np.mean(all_points, axis=0)

    for k, pline in named_polylines.items():
        named_polylines[k] = pline - centroid

    # Create system & simulation
    system = create_readdy_system(params)
    simulation = system.simulation(kernel="CPU")
    
    # Add a central point particle at the origin to mark (0,0,0)
    #TODO add particle here
    #simulation.add_particle("central_point1", np.array([0.0, 0.0, 0.0]))
    #simulation.add_particle("central_point2", np.array([0.0, 0.0, 0.0]))
    #simulation.add_particle("central_point3", np.array([0.0, 0.0, 0.0]))
    #simulation.add_particle("central_point4", np.array([0.0, 0.0, 0.0]))
    

    # 1) Build the bubble (no branches)
    bubble_positions = build_polyline_with_branches(
        named_polylines["bubble"],
        simulation,
        params["bond_length"],
        branch_chance=0.0,
        branch_length=params["branch_length"]  # length won't matter if chance=0
    )

    # 2) Build left, right, bottom with branch exclusion near bubble
    for name in ["left", "right", "bottom", "top", "upper_right","lower_right"]:
        build_polyline_with_branches(
            named_polylines[name],
            simulation,
            bond_length=params["bond_length"],
            branch_chance=params["branch_chance"],
            branch_length=params["branch_length"],
            exclude_positions=bubble_positions,
            exclude_radius=params["bubble_exclusion_radius"]
        )

    # Run the simulation
    run_simulation(simulation, params)


if __name__ == "__main__":
    main(PARAMS)

